package com.fullsecurity.demoapplication;

public interface ItemTouchHelperViewHolder {

    void onItemSelected(int position);

    void onItemClear(int position);

}
