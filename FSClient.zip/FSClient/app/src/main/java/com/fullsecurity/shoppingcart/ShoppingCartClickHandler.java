package com.fullsecurity.shoppingcart;

import android.view.View;

public interface ShoppingCartClickHandler {
    void handleItemClick(View view, ShoppingCart shoppingCart);
}
