package com.fullsecurity.storeitem;

import android.view.View;

public interface StoreItemClickHandler {
    void handleItemClick(View view, StoreItem storeItem);
}
