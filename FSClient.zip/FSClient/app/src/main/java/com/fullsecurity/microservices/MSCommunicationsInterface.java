package com.fullsecurity.microservices;

import com.fullsecurity.common.Payload;

public interface MSCommunicationsInterface {
    void setOutputPayloads(Payload request);
}
