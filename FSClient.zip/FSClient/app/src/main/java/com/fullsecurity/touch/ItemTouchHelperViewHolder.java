package com.fullsecurity.touch;

public interface ItemTouchHelperViewHolder {
    void onItemSelected();
    void onItemClear();
}
